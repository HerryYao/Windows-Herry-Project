0.1.0 version wrote by Herry.
It only supports Window Server right now.
Please don't unmount ISO image before script ends.
oscdimg is from WinPE add-on, and it is for create new ISO image.
Also make sure oscdimg.exe and efisys.bin are in same directory as script.ps1