#usrchosever variable is for storing the value of versions which usr chose
#vervalue contains number to winver
write-host "Windows Enterprise LTSC = 0(unavailable)
Windows Server Datacenter = 1"
$vervalue = @{"0" = "WINLTSC"; "1" = "WINSVRDC"}
$usrchosever = read-host "Tell me which version you want to activate(Type number)"

if ($vervalue.ContainsKey($usrchosever)) {
    $vervaluename = $vervalue[$usrchosever]
    Write-Host "You have chose $vervaluename
NOTE: Image you provided better be x64."
} else {
    Write-Host "No such Windows version available."
    exit 0
}
$isomountpath = Read-Host "Enter your $vervaluename(Evaluation) mounted ISO's drive letter"
#####INFO
if ($vervaluename = "WINSVRDC") {
    $exportindex = "4"
    $setedition = "ServerDatacenter"
    $winpkey = "WX4NM-KYWYW-QJJR4-XV3QB-6VM33"
} else {
    $exportindex = "1"
    $setedition = "lol"
    $winpkey = "lol"
}
#####/INFO
if (test-path -path $isomountpath":\sources") {
    $wimmountpath = read-host "
NOTE: Make sure you have right access permisson of that drive,
drive which wim will be mounted must be NTFS formated,
and make sure it has at least 15GB free space.
Detected mounted ISO, Where do you want to mount wim image?
Type a drive letter which is not same as mounted ISO's" 
    new-item -itemtype directory -path $wimmountpath":\wim\iso\tmp" -force
    write-host "Running... it may take a while"
    copy-item $isomountpath":\*" -exclude "install.wim" -destination $wimmountpath":\wim\iso" -recurse
    Export-WindowsImage -SourceImagePath $isomountpath":\sources\install.wim" -SourceIndex $exportindex -DestinationImagePath $wimmountpath":\wim\install.wim" -DestinationName $vervaluename -CompressionType Max
    Mount-WindowsImage -ImagePath $wimmountpath":\wim\install.wim" -Index 1 -Path $wimmountpath":\wim\iso\tmp"
    Set-WindowsEdition -Path $wimmountpath":\wim\iso\tmp" -Edition "$setedition"
    Set-WindowsProductKey -Path $wimmountpath":\wim\iso\tmp" -ProductKey "$winpkey"
    Dismount-WindowsImage -Path $wimmountpath":\wim\iso\tmp" -Save
    Move-Item -Path $wimmountpath":\wim\install.wim" -Destination $wimmountpath":\wim\iso\sources"
    remove-item -path $wimmountpath":\wim\iso\tmp"
    $wimmountpathplus = "${wimmountpath}:\"
    $currentlocation = get-location
    start-process -filepath "$currentlocation\oscdimg.exe" -argumentlist "-b$currentlocation\efisys.bin -pEF -u2 -udfver102 ${wimmountpathplus}wim\iso ${wimmountpathplus}\Windows.iso"
    write-host "Complete! Now activated ISO is in $wimmountpath":\""
    #remove-item -path $wimmountpath":\wim" -recurse -force
    read-host "Confirm exit?"
    exit 0
} else {
    write-host "SUSY BAKA, try again."
    Start-Sleep -Seconds 7
    exit 0
}